import React from "react";

function HomePage() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800">
      <div className="bg-gray-900 text-white p-8 rounded-2xl shadow-2xl border border-gray-700">
        <h1 className="text-3xl font-bold text-center mb-4">Welcome to DeepWatch</h1>
        <p className="text-gray-300 text-center">You are now logged in!</p>
      </div>
    </div>
  );
}

export default HomePage;