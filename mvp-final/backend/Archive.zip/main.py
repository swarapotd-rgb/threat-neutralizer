import os
from fastapi import FastAPI, Body
from typing import Optional, List
from pydantic import BaseModel, Field
from fastapi.middleware.cors import CORSMiddleware
from authenticator import *
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost", "http://127.0.0.1", "http://localhost:8000", "http://127.0.0.1:8000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

class AuthRequest(BaseModel):
    username: str
    password: str
    totp_code: str

class RegisterRequest(BaseModel):
    username:str
    password:str
    regtoken:str



@app.post("/login")
def login(given: AuthRequest):
    return loginuser(given.username, given.password, given.totp_code)











