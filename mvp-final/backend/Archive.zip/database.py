import sqlite3, uuid, time, json, datetime



conn = sqlite3.connect("secure.db", check_same_thread=False)
cursor=conn.cursor()



cursor.execute("""
CREATE TABLE IF NOT EXISTS regtokentable (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    regtoken TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL
)
""")
cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL,
    totp_secret TEXT NOT NULL,
    current_auth_token TEXT,
    otp TEXT,
    otp_expiry TEXT
)
""")


conn.commit()



def get_user_by_username(username):
    try:
        cur = conn.cursor()
        cur.execute("SELECT id, username, password_hash, role FROM users WHERE username = ?", (username,))
        user = cur.fetchone()
        if user:
            return {
                'id': user[0],
                'username': user[1],
                'password_hash': user[2],
                'role': user[3]
            }
        return None
    except Exception as e:
        print(f"Database error: {e}")
        return None

def verify_otp(username, otp):
    try:
        cursor.execute("""
            SELECT otp, otp_expiry 
            FROM users 
            WHERE username = %s
        """, (username,))
        result = cursor.fetchone()
        
        if not result:
            return False
            
        stored_otp, expiry_time = result
        current_time = datetime.now()
        
        if stored_otp == otp and current_time < expiry_time:
            cursor.execute("""
                UPDATE users 
                SET otp = NULL, otp_expiry = NULL 
                WHERE username = %s
            """, (username,))
            conn.commit()
            return True
            
        return False
        
    except Exception as e:
        print(f"Database error: {e}")
        return False
    finally:
        cursor.close()


